namespace DCR
{
    // ruleid: data-contract-resolver
    class MyDCR : DataContractResolver
    {
        public void ResolveDataContract()
        {
            
        }
    }
}
