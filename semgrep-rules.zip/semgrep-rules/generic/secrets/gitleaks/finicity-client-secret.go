// ruleid: finicity-client-secret
finicity_api_token = "a4krz2impyd4g0wpq9h0"