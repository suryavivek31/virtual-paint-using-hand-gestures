// ruleid: confluent-access-token
confluent_api_token = "mxyh8eh27blxt4s7"
