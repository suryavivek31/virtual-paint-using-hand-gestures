// ruleid: grafana-api-key
grafana-api-key_api_token = "eyJrIjoivdx25hwi2l4zwo8qn8szupf60vegv74pw1uf8bryv9zyvobnbjhwiqe0v42qv5wb7jf7uw"
grafana-cloud-api-token_api_token = "glc_hw2qgpmhzndkyw4zv6p5exn0la6g8vek"
