// ruleid: github-pat
github_api_token = "ghp_emmtytndiqky5a98w0s98w36vfhiz6f7ed4c"