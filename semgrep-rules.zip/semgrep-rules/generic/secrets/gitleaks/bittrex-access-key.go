// ruleid: bittrex-access-key
bittrex_api_token = "bdx13k0d9sv7j6nv97alzfmmf6iv75bx"
