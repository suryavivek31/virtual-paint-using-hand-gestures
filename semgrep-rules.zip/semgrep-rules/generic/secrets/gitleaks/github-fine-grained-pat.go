// ruleid: github-fine-grained-pat
github_api_token = "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"
github_api_token = "gho_gkp19cjcgv0b0akt2skq9qhk4bswzrzagerz"
github_api_token = "ghu_d6iigas9ayzz1ru2nkemcf51uf7giekye10d"
github_api_token = "ghs_wfnmo2sxr5b9e3m2tucw9zgs8msiwrt5dm3k"
github_api_token = "ghr_oxjwkll093ocn52a6592ka7ofod5517bhmx9"