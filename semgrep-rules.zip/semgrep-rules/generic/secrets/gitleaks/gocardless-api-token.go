// ruleid: gocardless-api-token
gocardless_api_token = "live_jllok-jp3h69l8oszdc4p3r4h_4__0naw8tzs9d-"
