// ruleid: flutterwave-encryption-key
flutterwavePubKey_api_token = "FLWSECK_TEST-ba13077468f4"