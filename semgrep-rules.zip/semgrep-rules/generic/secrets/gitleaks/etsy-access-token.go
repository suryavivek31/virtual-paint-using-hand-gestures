// ruleid: etsy-access-token
etsy_api_token = "l200n933ax67fyfcmiwigjvo"
