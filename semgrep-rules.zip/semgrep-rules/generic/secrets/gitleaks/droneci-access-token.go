// ruleid: droneci-access-token
droneci_api_token = "8jhgeerira7pgnzqab67xrqouxcyp3sw"
