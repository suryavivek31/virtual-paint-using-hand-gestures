// ruleid: beamer-api-token
beamer_api_token = "b_7s8tjugeydslyqykig3vrb9y29jchkuyweemc251cbv6"