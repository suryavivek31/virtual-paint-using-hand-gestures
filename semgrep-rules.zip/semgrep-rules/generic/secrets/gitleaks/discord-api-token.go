// ruleid: discord-api-token
discord_api_token = "94bec3f6741f06291e67cd8b90363b79c0b68024f65622c333d79f1055c4c65b"
