// ruleid: finicity-api-token
finicity_api_token = "5600675afe3e1a0fa76d5b99b30ca7a8"

