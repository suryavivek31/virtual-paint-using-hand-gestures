// ruleid: hubspot-api-key
const hubspotKey = "12345678-ABCD-ABCD-ABCD-1234567890AB"