// ruleid: gcp-api-key
gcp_api_token = "AIza9xk6puR24zxE7aIiv1pzH4N4jHXiOYP9EQ3"
