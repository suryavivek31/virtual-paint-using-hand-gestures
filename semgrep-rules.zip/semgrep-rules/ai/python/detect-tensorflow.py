# ruleid: detect-tensorflow
import tensorflow as tf
print("TensorFlow version:", tf.__version__)

# ruleid: detect-tensorflow
from tensorflow.keras import layers
# ruleid: detect-tensorflow
from tensorflow.keras import losses