# ruleid: deprecated_bxor_operator
Bitwise.bxor(1, 0)
