# ruleid: deprecated_bxor_operator
1 ^^^ 0
