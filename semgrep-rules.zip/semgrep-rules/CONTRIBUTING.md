# Contributions

We welcome contributions to this repo! Please fork and make a pull request; we'll contact you about signing our CLA.

See [Contributing to Semgrep rules](https://semgrep.dev/docs/contributing/contributing-to-semgrep-rules-repository/) in our docs page for more information on how you can contribute!

We're happy to help!

- Email us: [support@semgrep.com](mailto:support@semgrep.com)
- [Join our Slack](https://go.semgrep.dev/slack)
